#include "totvs.ch"

Static Function J61Mk()
	Local aSt := {{"C7_FILIAL","C",2,0},{"C7_NUM","C",6,0},{"C7_ITEM","C",4,0},{"C7_PRODUTO","C",15,0},;
		{"C7_FORNECE","C",6,0},{"C7_LOJA","C",2,0},{"C7_EMISSAO","D",8,0},{"C7_DATPRF","D",8,0},{"C7_XDTVAL","D",8,0}}
	FErase("/stub_sc7.dbf")
	DBCreate("/stub_sc7.dbf", aSt, "DBFCDX")
	DBUseArea(.T., "DBFCDX", "/stub_sc7.dbf", "SC7", .T., .F.)
Return

Static Function J61Cnt(cF)
	Local cT := If(File(cF), MemoRead(cF), "")
	Local nL := Len(cT) - Len(StrTran(cT, Chr(10), ""))
Return If(nL > 0, nL - 1, 0)

// aCasos: {id, xdtval, datprf, emissao, dRef, MV_XTOLRES, lEscada, nTipo, lEsperado, lAviso}
// Saida em /j61res.txt: 2 bytes por caso = Chr(64 + lRet + 2*ok + 4*aviso) e Chr(32 + tolerancia/2); 1 byte final do CSV.
User Function J61ALL()
	Local aC := {}
	Local cRes := ""
	Local cArq := "\jmp21\aviso_compras.csv"
	Local nFail := 0
	Local nI := 0
	Local lRet := .F.
	Local nA0 := 0
	Local nA1 := 0
	Local lOk := .F.
	Local cD := ""
	Local nAv := 0
	Local nTolU := 0
	Local oErr
	Local bOld
	Public dDataBase := Date()

	AAdd(aC, {"CT01a", SToD("20260630"), SToD("20260101"), SToD("20250101"), SToD("20260701"), 0, .T., 1, .T., .F.})
	AAdd(aC, {"CT01b", SToD("20260630"), SToD("20260101"), SToD("20250101"), SToD("20260629"), 0, .T., 1, .F., .F.})
	AAdd(aC, {"CT01c", SToD("20260630"), SToD("20260101"), SToD("20250101"), SToD("20260630"), 0, .T., 1, .F., .F.})
	AAdd(aC, {"CT02a", SToD("20261231"), SToD("20250301"), SToD("20250101"), SToD("20261029"), 0, .T., 1, .F., .F.})
	AAdd(aC, {"CT02b", SToD("20261231"), SToD("20250301"), SToD("20250101"), SToD("20270101"), 0, .T., 1, .T., .F.})
	AAdd(aC, {"CT03a", CToD(""), SToD("20260301"), SToD("20250101"), SToD("20260827"), 0, .T., 1, .F., .F.})
	AAdd(aC, {"CT03b", CToD(""), SToD("20260301"), SToD("20250101"), SToD("20260828"), 0, .T., 1, .F., .F.})
	AAdd(aC, {"CT03c", CToD(""), SToD("20260301"), SToD("20250101"), SToD("20260829"), 0, .T., 1, .T., .F.})
	AAdd(aC, {"CT03d", CToD(""), SToD("20260301"), SToD("20250101"), SToD("20260829"), 182, .T., 1, .F., .F.})
	AAdd(aC, {"CT04a", CToD(""), CToD(""), SToD("20260301"), SToD("20260828"), 0, .T., 1, .F., .F.})
	AAdd(aC, {"CT04b", CToD(""), CToD(""), SToD("20260301"), SToD("20260829"), 0, .T., 1, .T., .F.})
	AAdd(aC, {"CT04c", CToD(""), CToD(""), SToD("20261202"), SToD("20270131"), 0, .T., 1, .F., .F.})
	AAdd(aC, {"CT04d", CToD(""), CToD(""), SToD("20261202"), SToD("20270202"), 0, .T., 1, .T., .F.})
	AAdd(aC, {"CT04e", CToD(""), CToD(""), CToD(""), SToD("20261029"), 0, .T., 1, .F., .T.})
	AAdd(aC, {"CT05a1", CToD(""), SToD("20260501"), SToD("20250101"), SToD("20261029"), 0, .T., 1, .T., .F.})
	AAdd(aC, {"CT05a2", CToD(""), SToD("20260502"), SToD("20250101"), SToD("20261029"), 0, .T., 1, .F., .F.})
	AAdd(aC, {"CT05b1", CToD(""), SToD("20260602"), SToD("20250101"), SToD("20261130"), 0, .T., 1, .T., .F.})
	AAdd(aC, {"CT05b2", CToD(""), SToD("20260603"), SToD("20250101"), SToD("20261130"), 0, .T., 1, .F., .F.})
	AAdd(aC, {"CT05c1", CToD(""), SToD("20260802"), SToD("20250101"), SToD("20261201"), 0, .T., 1, .T., .F.})
	AAdd(aC, {"CT05c2", CToD(""), SToD("20260803"), SToD("20250101"), SToD("20261201"), 0, .T., 1, .F., .F.})
	AAdd(aC, {"CT05d1", CToD(""), SToD("20260901"), SToD("20250101"), SToD("20261231"), 0, .T., 1, .T., .F.})
	AAdd(aC, {"CT05d2", CToD(""), SToD("20260902"), SToD("20250101"), SToD("20261231"), 0, .T., 1, .F., .F.})
	AAdd(aC, {"CT05e1", CToD(""), SToD("20261002"), SToD("20250101"), SToD("20270101"), 0, .T., 1, .T., .F.})
	AAdd(aC, {"CT05e2", CToD(""), SToD("20261003"), SToD("20250101"), SToD("20270101"), 0, .T., 1, .F., .F.})
	AAdd(aC, {"CT05f1", CToD(""), SToD("20261101"), SToD("20250101"), SToD("20270131"), 0, .T., 1, .T., .F.})
	AAdd(aC, {"CT05f2", CToD(""), SToD("20261102"), SToD("20250101"), SToD("20270131"), 0, .T., 1, .F., .F.})
	AAdd(aC, {"CT05g1", CToD(""), SToD("20261202"), SToD("20250101"), SToD("20270201"), 0, .T., 1, .T., .F.})
	AAdd(aC, {"CT05g2", CToD(""), SToD("20261203"), SToD("20250101"), SToD("20270201"), 0, .T., 1, .F., .F.})
	AAdd(aC, {"ESC0a", CToD(""), SToD("20260804"), SToD("20250101"), SToD("20270201"), 0, .F., 1, .T., .F.})
	AAdd(aC, {"ESC0b", CToD(""), SToD("20260805"), SToD("20250101"), SToD("20270201"), 0, .F., 1, .F., .F.})
	AAdd(aC, {"OVR1", CToD(""), SToD("20261212"), SToD("20250101"), SToD("20270201"), 50, .T., 1, .T., .F.})
	AAdd(aC, {"OVR2", CToD(""), SToD("20261213"), SToD("20250101"), SToD("20270201"), 50, .T., 1, .F., .F.})
	AAdd(aC, {"TP2", CToD(""), CToD(""), CToD(""), SToD("20261029"), 0, .T., 2, .T., .F.})
	AAdd(aC, {"TP3", CToD(""), CToD(""), CToD(""), SToD("20261029"), 0, .T., 3, .T., .F.})

	bOld := ErrorBlock({|e| oErr := e, Break(e)})
	Begin Sequence
		J61Mk()
		FErase(cArq)
		For nI := 1 To Len(aC)
			SC7->(DBGoTop())
			If SC7->(Eof())
				SC7->(DBAppend())
			EndIf
			SC7->C7_FILIAL := "99"
			SC7->C7_NUM := "J61" + StrZero(nI, 3)
			SC7->C7_ITEM := "0001"
			SC7->C7_PRODUTO := "PRODTESTE"
			SC7->C7_FORNECE := "000001"
			SC7->C7_LOJA := "01"
			SC7->C7_EMISSAO := aC[nI][4]
			SC7->C7_DATPRF := aC[nI][3]
			SC7->C7_XDTVAL := aC[nI][2]
			dDataBase := aC[nI][5]
			nA0 := J61Cnt(cArq)
			nTolU := U_J21TOL(dDataBase, aC[nI][6], aC[nI][7], U_J21ESCDF())
			lRet := U_J21PE({"SC7", aC[nI][8]}, aC[nI][6], aC[nI][7], U_J21ESCDF())
			nA1 := J61Cnt(cArq)
			lOk := (lRet == aC[nI][9]) .And. ((nA1 - nA0) == If(aC[nI][10], 1, 0))
			If !lOk
				nFail++
			EndIf
			If aC[nI][10]
				nAv := nI
			EndIf
			cRes += Chr(64 + If(lRet, 1, 0) + If(lOk, 2, 0) + If(nA1 > nA0, 4, 0)) + Chr(32 + Int(nTolU / 2))
		Next nI
		cD := MemoRead(cArq)
		cRes += Chr(64 + If(J61Cnt(cArq) == 1, 1, 0) + If(("J61" + StrZero(nAv, 3)) $ cD, 2, 0) + If("Sem data limite" $ cD, 4, 0))
		MemoWrite("/j61csv.txt", cD)
	Recover
		cRes += "!" + oErr:Description
		nFail += 100
	End Sequence
	ErrorBlock(bOld)
	SC7->(DBCloseArea())
	FErase("/stub_sc7.dbf")
	FErase("/stub_sc7.cdx")
	FErase(cArq)
	DirRemove("\jmp21\")
	MemoWrite("/j61res.txt", cRes)
Return nFail
