# JMP-61 - resultado dos casos (escada ligada por padrao, MV_XTOLRES=0)

Harness: src/J61TEST.prw (U_J61ALL). SC7 simulada em DBF, dDataBase fixada por caso, PE exercitado via U_J21PE/U_J21TOL. RUN_RC de U_J61ALL = 0 (0 falhas). Bytes lidos do RPO de teste: bytes_J61ALL.txt.

| Caso | XDTVAL | DATPRF | EMISSAO | Ref (dDataBase) | MV_XTOLRES | Escada | Tol. aplicada | Esperado | Retorno do PE | Aviso | Resultado |
|---|---|---|---|---|---|---|---|---|---|---|---|
| CT01a | 30/06/2026 | 01/01/2026 | 01/01/2025 | 01/07/2026 | 0 | ligada | 180 | ELIMINA | .T. (libera) | nao | PASS |
| CT01b | 30/06/2026 | 01/01/2026 | 01/01/2025 | 29/06/2026 | 0 | ligada | 180 | MANTEM | .F. (mantem) | nao | PASS |
| CT01c | 30/06/2026 | 01/01/2026 | 01/01/2025 | 30/06/2026 | 0 | ligada | 180 | MANTEM | .F. (mantem) | nao | PASS |
| CT02a | 31/12/2026 | 01/03/2025 | 01/01/2025 | 29/10/2026 | 0 | ligada | 180 | MANTEM | .F. (mantem) | nao | PASS |
| CT02b | 31/12/2026 | 01/03/2025 | 01/01/2025 | 01/01/2027 | 0 | ligada | 90 | ELIMINA | .T. (libera) | nao | PASS |
| CT03a | - | 01/03/2026 | 01/01/2025 | 27/08/2026 | 0 | ligada | 180 | MANTEM | .F. (mantem) | nao | PASS |
| CT03b | - | 01/03/2026 | 01/01/2025 | 28/08/2026 | 0 | ligada | 180 | MANTEM | .F. (mantem) | nao | PASS |
| CT03c | - | 01/03/2026 | 01/01/2025 | 29/08/2026 | 0 | ligada | 180 | ELIMINA | .T. (libera) | nao | PASS |
| CT03d | - | 01/03/2026 | 01/01/2025 | 29/08/2026 | 182 | ligada | 182 | MANTEM | .F. (mantem) | nao | PASS |
| CT04a | - | - | 01/03/2026 | 28/08/2026 | 0 | ligada | 180 | MANTEM | .F. (mantem) | nao | PASS |
| CT04b | - | - | 01/03/2026 | 29/08/2026 | 0 | ligada | 180 | ELIMINA | .T. (libera) | nao | PASS |
| CT04c | - | - | 02/12/2026 | 31/01/2027 | 0 | ligada | 90 | MANTEM | .F. (mantem) | nao | PASS |
| CT04d | - | - | 02/12/2026 | 02/02/2027 | 0 | ligada | 60 | ELIMINA | .T. (libera) | nao | PASS |
| CT04e | - | - | - | 29/10/2026 | 0 | ligada | 180 | MANTEM + AVISO | .F. (mantem) | sim | PASS |
| CT05a1 | - | 01/05/2026 | 01/01/2025 | 29/10/2026 | 0 | ligada | 180 | ELIMINA | .T. (libera) | nao | PASS |
| CT05a2 | - | 02/05/2026 | 01/01/2025 | 29/10/2026 | 0 | ligada | 180 | MANTEM | .F. (mantem) | nao | PASS |
| CT05b1 | - | 02/06/2026 | 01/01/2025 | 30/11/2026 | 0 | ligada | 180 | ELIMINA | .T. (libera) | nao | PASS |
| CT05b2 | - | 03/06/2026 | 01/01/2025 | 30/11/2026 | 0 | ligada | 180 | MANTEM | .F. (mantem) | nao | PASS |
| CT05c1 | - | 02/08/2026 | 01/01/2025 | 01/12/2026 | 0 | ligada | 120 | ELIMINA | .T. (libera) | nao | PASS |
| CT05c2 | - | 03/08/2026 | 01/01/2025 | 01/12/2026 | 0 | ligada | 120 | MANTEM | .F. (mantem) | nao | PASS |
| CT05d1 | - | 01/09/2026 | 01/01/2025 | 31/12/2026 | 0 | ligada | 120 | ELIMINA | .T. (libera) | nao | PASS |
| CT05d2 | - | 02/09/2026 | 01/01/2025 | 31/12/2026 | 0 | ligada | 120 | MANTEM | .F. (mantem) | nao | PASS |
| CT05e1 | - | 02/10/2026 | 01/01/2025 | 01/01/2027 | 0 | ligada | 90 | ELIMINA | .T. (libera) | nao | PASS |
| CT05e2 | - | 03/10/2026 | 01/01/2025 | 01/01/2027 | 0 | ligada | 90 | MANTEM | .F. (mantem) | nao | PASS |
| CT05f1 | - | 01/11/2026 | 01/01/2025 | 31/01/2027 | 0 | ligada | 90 | ELIMINA | .T. (libera) | nao | PASS |
| CT05f2 | - | 02/11/2026 | 01/01/2025 | 31/01/2027 | 0 | ligada | 90 | MANTEM | .F. (mantem) | nao | PASS |
| CT05g1 | - | 02/12/2026 | 01/01/2025 | 01/02/2027 | 0 | ligada | 60 | ELIMINA | .T. (libera) | nao | PASS |
| CT05g2 | - | 03/12/2026 | 01/01/2025 | 01/02/2027 | 0 | ligada | 60 | MANTEM | .F. (mantem) | nao | PASS |
| ESC0a | - | 04/08/2026 | 01/01/2025 | 01/02/2027 | 0 | desligada | 180 | ELIMINA | .T. (libera) | nao | PASS |
| ESC0b | - | 05/08/2026 | 01/01/2025 | 01/02/2027 | 0 | desligada | 180 | MANTEM | .F. (mantem) | nao | PASS |
| OVR1 | - | 12/12/2026 | 01/01/2025 | 01/02/2027 | 50 | ligada | 50 | ELIMINA | .T. (libera) | nao | PASS |
| OVR2 | - | 13/12/2026 | 01/01/2025 | 01/02/2027 | 50 | ligada | 50 | MANTEM | .F. (mantem) | nao | PASS |
| TP2 | - | - | - | 29/10/2026 | 0 | ligada | 180 | tipo 2: .T. (nao afeta) | .T. (libera) | nao | PASS |
| TP3 | - | - | - | 29/10/2026 | 0 | ligada | 180 | tipo 3: .T. (nao afeta) | .T. (libera) | nao | PASS |

CSV de aviso: 1 linha de dado = sim; contem o pedido do caso CT04e = sim; contem o motivo 'Sem data limite' = sim
Falhas: 0 de 34 casos
