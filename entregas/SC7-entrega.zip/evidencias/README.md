# JMP-61 - evidencia (teste, LXC 109, protheus-2510, empresa 990)
- compile_MT235G2.log / compile_J61TEST.log / compile_J61RD.log: COMPILE_RC=0, Errors(0), RPO custom.rpo.
- run_J61ALL.log: RUN_RC=0 (0 falhas em 34 casos + CSV de aviso). Detalhe: resultado_casos.md.
- run_J61FF.log: RUN_RC=31 (U_MT235G2, ExistBlock, U_J21PE, U_J21DECID, U_MA235PC presentes).
- ct05/: antes/depois do SX6 MV_XTOLRES (180 -> 0) e saida do dict-write.
- probat_final.log: PROBAT_RESULT=CHECK (tests=6 ok=1 failures=5), igual ao estado de 15:01; ver comentario do issue.
