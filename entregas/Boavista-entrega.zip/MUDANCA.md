# Boavista — ORTA023D.PRW (JMP-57/84/85)
- Roteamento Vero/Banrisul corrigido (BJRVC* -> Vero, pos73/pos43)
- Banese reg.4 processado; reg.3 semantica conservadora
- Credishop 3.4/3.4.1 via CredLay341()
- u_JobCInfo() instrumentado em todos os ramos (JMP-85)
- COMPILE_RC=0; exec Dev 04:05 "vendas: 21"; amostras reais em tecnico/JMP-57/banrisul-real/
