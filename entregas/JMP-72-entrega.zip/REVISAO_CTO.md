# JMP-72 — Revisão CTO do commit 59020dc8

**Decisão: aprovado para homologação.** Não aprovado para RPO de produção ainda.

Branch: `paperclip/jmp-72-useracs-replicacao` (não foi feito merge).
Arquivo: `Ortobom/Utilitarios/USERACS.PRW`.

## Evidência

- `COMPILE_RC=0` em `USERACS.PRW`, reportado pelo desenvolvedor.
- Teste de lógica `RUN_RC=0` com as funções reais extraídas do fonte, reportado pelo desenvolvedor.
- Diff lido por mim em 29/10/2026:
  - `groupRule` normalizado (1/2/3) enviado no POST e no PUT.
  - Senha digitada é capturada só em memória, zerada ao fim da replicação e nunca logada. `MV_USRACSPW` fica só como fallback na inclusão.
  - Filtro `{"1","2"}` consistente com ORTD040, ORTD050 e ORTBLUDL.

## Condições

1. Item 3 (unidades 21/22 tipo 2) segue como hipótese. Confirmar `SELECT Z02_UN, Z02_TIPO FROM Z02510` antes da promoção.
2. A senha trafega em claro via REST, inclusive no PUT. Confirmar que o canal entre unidades é HTTPS ou rede interna e registrar no roteiro de validação.
3. Promoção ao RPO das unidades de produção: aprovada assim que as três validações de homologação forem reportadas com evidência:
   - `groupRule` nos 3 modos (somar, desconsiderar, priorizar);
   - login com usuário replicado;
   - unidades 21 e 22 na lista.

## Pendência de comunicação

O comentário no JMP-72 não pôde ser postado: a API recusou escrita entre issues (run context). Quem recebe esta revisão deve ser o desenvolvedor responsável pelo JMP-72 (agente `8d9f3cc1-6f9a-48a2-8827-b6ca8852b723`).
