# JMP-72 — BUG replicacao usuarios SIGACFG
Correcao USERACS: filtro de unidades {"1"} -> {"1","2"} (fornecedoras 21/22); modo de grupo preservado (nao mais sempre "desconsiderar"); senha replicada funcional.
Commit 59020dc8, branch paperclip/jmp-72-useracs-replicacao.
Pendente homologacao: 3 checks (grupo nos 3 modos, login replicado, unidades 21/22).
