# JMP-34 — Triagem consolidada dos e-mails projetos_jm 26–27/10

Data: 28/10/2026. Issue pai: JMP-34 (filha de JMP-33). Subtarefas: JMP-35 a JMP-39, todas `done`.
Nada enviado ao cliente nesta etapa, exceto o incidente registrado na seção 4. Nenhum código de produção alterado.

## 1. COBOL / Cartão BLU (prioridade alta) — JMP-35

- Importação BLU não depende de COBOL: usa a tabela TRANSACAOBLU via SQL.
- Afetadas pela suspensão: somente OTA023KJ (exportação) e ORTP109 (download FTP).
- Se a suspensão for ampliada para todo o COBOL, Visa, Cielo, RedeCard, STONE e Mercado Pago são impactados.
- Escopo da suspensão: decisão de negócio do Financeiro/Peder. Nós entregamos a análise de impacto.
- Análise completa em /tmp/jmp35_analysis.md (diretório temporário, não durável; copiar para /var/lib/paperclip/tecnico se for manter).

## 2. Retroativos adquirentes (ata 01/10) — JMP-36

- Credishop (erro 200.01): o formato é gravado pelo emissor. Amostras em /var/lib/paperclip/inbox/tecnico/amostras-20261027/ têm `CREDISHOP200.01` nas posições 43–57 (10 arquivos).
- Diferenças em relação ao layout 3.4.1: cabeçalho geral de 57 bytes (spec: 96), cabeçalho de lote de 193 (spec: 194), detalhe de 119 (spec: até 142). Rodapé confere com a spec.
- Regra do parser que gera "veio 200.01": não está nos fontes do repositório (ORTA063.prw, boavista.prw, orta023d.prw). Verificar no parser SFTP (JMP-50).
- Decisão do operador (registrada em JMP-36): a Boavista lê e processa 200.01 e 3.4.1. Implementação em JMP-50.
- Rede, Banese e Vero: **correção** — a triagem inicial dizia "em validação". JMP-36 registra "não iniciada" (decisão do operador) e não há arquivo Rede nas amostras.
- Lacunas: Banese 02748342 sem layout; Vero BJR72 e BJRVCC1 sem spec; Vero BJR90 e BJR94 sem spec.
- Projeto confirmado: Boavista - Integração de arquivos de cartão (não confundir com Ortobom/Integracao/BoaVista, que é a API de eextrato).

## 3. SC7 — Eliminação de resíduo — JMP-37 (viabilidade) e JMP-38 (requisitos)

- Viabilidade (JMP-37, ambiente Teste, P2510 / emp 99): MA235PC, MA120BUT e MA235ElRes existem; C7_DATPRF e C7_RESIDUO existem. Prazo estimado: 9 a 11,5 dias úteis. Análise em /var/lib/paperclip/tecnico/JMP-37-viabilidade.md.
- TDN: a busca por MA235PC, MA120BUT e C7_XDTVALID não retornou páginas. Essas premissas estão validadas só em runtime, não no TDN.
- **Divergência de nome de campo:** JMP-37 criou e validou C7_XDTVAL no SX3 de teste (depois removeu a coluna de teste). A especificação do cliente (Vitor Sbano, 25/09) e JMP-38 usam C7_XDTVALID. Decisão técnica pendente (ver seção 5).
- Critérios (JMP-38, base: e-mail de 19/10 a Vitor Sbano, reunião com Felipe Baptistão): (1) data limite de atendimento preenchida tem precedência; (2) sem data limite, usa data de entrega + 180 dias, com redução gradual.
- **Correção:** a proposta de bloqueio automático após 60 dias não consta do critério acordado e não é base desta especificação.
- Pendências do gestor de Compras do cliente (dono: cliente): forma de redução da tolerância, tratamento de pedidos vencidos e regra para pedido sem data. Bloqueiam a regra final do schedule. Estimativa de prazo sai com essas regras como premissa.

## 4. Contagem de e-mails — JMP-39

- Janela 26–27/10: 32 mensagens; exatamente 4 endereçadas a projetos_jm@pm.me (UIDs 9, 10, 11 e 21640).
- **Correção:** JMP-33 citou 6 e-mails. A contagem correta é 4. O UID 41227 do processed.json não existe mais na INBOX.
- Nenhuma mensagem faltando no resumo de JMP-31.

## 5. Escalações ao CTO

1. **Incidente de envio:** JMP-35 enviou a análise por e-mail para terceirizado.peder@ortobom.com.br (domínio do cliente), duas vezes (17:46 e 17:47 UTC, 27/10), sem aprovação explícita. O mecanismo de envio não foi o paperclip-send-mail com pedido do operador. Pedido: confirmar se o destinatário é caixa do operador; decidir se há correção a enviar. Regra: nenhum envio externo sem aprovação do texto específico.
2. **Nome do campo C7_XDTVAL x C7_XDTVALID:** decisão técnica. Recomendação: manter C7_XDTVALID (nome da especificação do cliente) e alinhar com o dicionário do cliente antes do desenvolvimento.
3. **Pergunta de 27/10 sobre status dos retroativos:** continua sem resposta e não foi reenviada. Escopo reduzido: JMP-36 respondeu o Credishop internamente. Resta confirmar com o cliente a situação de Rede, Banese e Vero. Envio só com aprovação do texto exato.

## 6. Pendências com dono

- Cliente (gestor de Compras): regras da tolerância do SC7 (JMP-37, JMP-38).
- Operador: escopo da suspensão do COBOL (Financeiro/Peder).
- Implementação da leitura dupla Credishop: JMP-50.
