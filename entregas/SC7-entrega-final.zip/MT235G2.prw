#include "totvs.ch"
#include "fileio.ch"

/*/{Protheus.doc} MT235G2
Ponto de entrada MT235G2 (MATA235, eliminacao de residuo) - JMP-21 / JMP-61.
Chamado pela MA235PC para cada registro de SC7 ja posicionado (SC7->), com
ParamIXB = {alias, nTipo}. O alias recebido e o da query (so tem colunas fixas e
nao tem C7_XDTVAL): por isso toda checagem usa SC7->.
Retorno: .T. libera o registro para a eliminacao padrao; .F. pula o registro
(MA235PC faz dbSkip/Loop). Depois do .T. o padrao ainda aplica o percentual de
residuo (MV_par01) e QUANT > QUJE: esta regra so FILTRA o que o padrao eliminaria.
nTipo 1 = SC7 (pedido); 2 = SC3 e 3 = SC1 ficam fora do escopo (retorna .T.).

Regra por registro:
 1. C7_XDTVAL preenchido: libera so se dDataBase > C7_XDTVAL (criterio 01).
 2. C7_XDTVAL vazio e C7_DATPRF preenchido: libera so se
    dDataBase > C7_DATPRF + tolerancia (criterio 02). Campo preenchido vence.
 3. Sem C7_XDTVAL e sem C7_DATPRF: usa C7_EMISSAO + tolerancia vigente.
 4. Sem nenhuma das tres datas: nao libera e registra aviso ao Compras.
Tolerancia (pela data de processamento dDataBase):
 - MV_XTOLRES > 0: valor fixo (override); MV_XTOLRES = 0: usa a escada.
 - Escada (MV_XESCON, padrao .T.; MV_XESCAL "AAAAMMDD:dias;..."): ate 30/11/2026
   = 180; 01/12/2026 a 31/12/2026 = 120; 01/01/2027 a 31/01/2027 = 90; a partir
   de 01/02/2027 = 60. Antes do primeiro corte vale a base de 180 dias.

Premissas: data de referencia = dDataBase (a confirmar); pedidos ja vencidos
recebem a mesma regra, sem tratamento especial (ordem do operador).
@type User Function
/*/
User Function MT235G2()
	Local aPar    := If(Type("PARAMIXB") == "A", PARAMIXB, {})
	Local nTol    := SuperGetMV("MV_XTOLRES", .F., 0)
	Local lEscada := SuperGetMV("MV_XESCON", .F., .T.)
	Local cEscada := SuperGetMV("MV_XESCAL", .F., U_J21ESCDF())
Return U_J21PE(aPar, nTol, lEscada, cEscada)

/*/{Protheus.doc} J21PE
Corpo do MT235G2 com os parametros ja resolvidos (separado para teste sem ambiente).
/*/
User Function J21PE(aPar, nTolMV, lEscada, cEscada)
	Local nTipo := If(Len(aPar) >= 2, aPar[2], 0)
	Local dRef  := dDataBase
	Local nTol  := 0
	Local aRes  := {}

	If nTipo <> 1
		Return .T.
	EndIf

	If SC7->(FieldPos("C7_XDTVAL")) == 0
		ConOut("[JMP-21] MT235G2: campo C7_XDTVAL inexistente no dicionario; eliminacao bloqueada")
		Return .F.
	EndIf

	nTol := U_J21TOL(dRef, nTolMV, lEscada, cEscada)
	aRes := U_J21DECID(dRef, SC7->C7_XDTVAL, SC7->C7_DATPRF, SC7->C7_EMISSAO, nTol)

	If aRes[1] == 3
		J21Aviso(aRes[2])
	EndIf
Return aRes[1] == 1

/*/{Protheus.doc} J21DECID
Decisao pura. Retorna {nAcao, cMotivo}: 1 = libera para eliminar; 2 = mantem;
3 = mantem e avisa o Compras (sem C7_XDTVAL, sem C7_DATPRF e sem C7_EMISSAO).
/*/
User Function J21DECID(dRef, dXDtVal, dDatPrf, dEmissao, nTol)
	Local nAcao := 2
	Local cMot  := ""

	If !Empty(dXDtVal)
		If dRef > dXDtVal
			nAcao := 1
			cMot  := "CRIT01 data de referencia posterior a data limite"
		Else
			cMot  := "CRIT01 data de referencia ate a data limite"
		EndIf
	ElseIf !Empty(dDatPrf)
		If dRef > dDatPrf + nTol
			nAcao := 1
			cMot  := "CRIT02 data de referencia posterior a entrega + tolerancia"
		Else
			cMot  := "CRIT02 data de referencia ate a entrega + tolerancia"
		EndIf
	ElseIf !Empty(dEmissao)
		If dRef > dEmissao + nTol
			nAcao := 1
			cMot  := "CRIT02 sem entrega: data de referencia posterior a emissao + tolerancia"
		Else
			cMot  := "CRIT02 sem entrega: data de referencia ate a emissao + tolerancia"
		EndIf
	Else
		nAcao := 3
		cMot  := "Sem data limite (C7_XDTVAL), sem data de entrega (C7_DATPRF) e sem emissao (C7_EMISSAO)"
	EndIf
Return {nAcao, cMot}

// Escada padrao (MV_XESCAL): corte inicial do degrau e dias. Base de 180 dias antes do primeiro corte.
User Function J21ESCDF()
Return "20261201:120;20270101:90;20270201:60"

/*/{Protheus.doc} J21TOL
Tolerancia vigente em dRef. nTolMV > 0 e override fixo; 0 usa a escada (se ligada) ou a base de 180.
/*/
User Function J21TOL(dRef, nTolMV, lEscada, cEscada)
	Local nTol    := 180
	Local dMelhor := CToD("")
	Local aPas    := {}
	Local aPar    := {}
	Local dCorte  := CToD("")
	Local nI      := 0

	If ValType(nTolMV) == "N" .And. nTolMV > 0
		Return nTolMV
	EndIf

	If ValType(lEscada) == "L" .And. lEscada .And. !Empty(cEscada)
		aPas := StrTokArr(AllTrim(cEscada), ";")
		For nI := 1 To Len(aPas)
			aPar := StrTokArr(aPas[nI], ":")
			If Len(aPar) == 2
				dCorte := SToD(AllTrim(aPar[1]))
				If !Empty(dCorte) .And. dRef >= dCorte .And. (Empty(dMelhor) .Or. dCorte >= dMelhor)
					dMelhor := dCorte
					nTol    := Val(aPar[2])
				EndIf
			EndIf
		Next nI
	EndIf
Return nTol

// Lista de aviso ao Compras: \jmp21\aviso_compras.csv (acumulativo) + console.
Static Function J21Aviso(cMotivo)
	Local cDir := "\jmp21\"
	Local cArq := cDir + "aviso_compras.csv"
	Local cNew := ""
	Local cLin := ""
	Local nH   := -1

	cLin := DToS(Date()) + ";" + Time() + ";" + SC7->C7_FILIAL + ";" + SC7->C7_NUM + ";" + SC7->C7_ITEM + ";" + ;
		AllTrim(SC7->C7_PRODUTO) + ";" + SC7->C7_FORNECE + "/" + SC7->C7_LOJA + ";" + DToS(SC7->C7_EMISSAO) + ";" + cMotivo + CRLF

	If !ExistDir(cDir)
		MakeDir(cDir)
	EndIf
	If File(cArq)
		nH := FOpen(cArq, FO_READWRITE + FO_SHARED)
		If nH >= 0
			FSeek(nH, 0, FS_END)
		EndIf
	Else
		nH := FCreate(cArq)
		If nH >= 0
			cNew := "data;hora;filial;pedido;item;produto;fornecedor;emissao;motivo" + CRLF
			FWrite(nH, cNew)
		EndIf
	EndIf
	If nH >= 0
		FWrite(nH, cLin)
		FClose(nH)
	EndIf
	ConOut("[JMP-21] AVISO COMPRAS pedido " + SC7->C7_NUM + "/" + SC7->C7_ITEM + ": " + cMotivo)
Return
