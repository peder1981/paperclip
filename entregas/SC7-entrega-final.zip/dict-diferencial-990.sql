-- JMP-21 dicionario diferencial (empresa 990 teste) — replicar no cliente na homologacao
-- SX3 (SC7): C7_XDTVAL reaproveitado como data limite de atendimento
UPDATE sx3990 SET x3_titulo='Dt Lim Atend', x3_valid='', x3_relacao='', x3_trigger='N' WHERE x3_campo='C7_XDTVAL' AND d_e_l_e_t_=' ';
-- SX6: tolerancia residuo (0=escada 180/120/90/60 por data de corte; >0=override fixo)
INSERT INTO sx6990 (x6_var,x6_tipo,x6_conteud,x6_descric,x6_propri) VALUES ('MV_XTOLRES','N','180','Tolerancia em dias para residuo','U');
