# SC7 — Eliminação de resíduo por data limite (JMP-21)

## Conteúdo do pacote
- `MT235G2.prw` — ponto de entrada por registro (MATA235); único fonte de produção, autocontido
- `dict-diferencial-990.sql` — ajustes de dicionário (SX3 C7_XDTVAL + SX6 MV_XTOLRES)
- Este documento

## Regra implementada
1. C7_XDTVAL preenchido → governa (critério 01)
2. Vazio → C7_DATPRF + tolerância vigente (critério 02)
3. Sem nenhuma data → C7_EMISSAO + tolerância; aviso ao Compras
4. Escada por data de corte: 180d até 30/11/26; 120d ≥01/12/26; 90d ≥01/01/27; 60d ≥01/02/27
5. MV_XTOLRES=0 ativa a escada; >0 = tolerância fixa (override)

## Validação
COMPILE_RC=0; harness 34 casos / 0 falhas cobrindo CT-01..CT-05 e os 4 cortes.
ProBat tlppCore CHECK 5/6 = falha pré-existente do núcleo TLPP (determinística em 7 runs), não do código.
RPO de teste já contém o fonte compilado (protheus-2510, backup bak_202610292327).

## Pendente para produção (JMP-56)
e2e com SC7 real; leitura SX3/SX6 da base cliente; aplicar dict-diferencial + fonte no RPO vivo.
