# Dicionário ZM1/ZM2/ZM3 (aplicar no teste, empresa 99; NÃO aplicado)
SX2: ZM1 "Funcoes Monitor" modo C/C/C; ZM2 "Agenda Monitor" C/C/C; ZM3 "Log Monitor" C/C/C. Arquivo ZMn+emp+"0".
SIX: ZM1 ord1 ZM1_FILIAL+ZM1_COD | ZM2 ord1 ZM2_FILIAL+ZM2_COD+ZM2_SEQ | ZM3 ord1 ZM3_FILIAL+ZM3_ID; ZM3 ord2 ZM3_FILIAL+ZM3_COD+DTOS(ZM3_DATA)+ZM3_HORA
SX3 (campo, tipo, tam, dec, título):
ZM1: ZM1_FILIAL C 2 0 | ZM1_COD C 6 0 Código | ZM1_DESC C 40 0 Descrição | ZM1_ROTINA C 20 0 User Function (sem U_) | ZM1_ATIVO C 1 0 Ativo S/N (padrão "S") | ZM1_TOLER N 3 0 Tolerância min (padrão 15) | ZM1_TMOUT N 4 0 Timeout min (padrão 30) | ZM1_RETRY N 2 0 Retentativas (padrão 2) | ZM1_BACKOF N 3 0 Espera retentativa min (padrão 5)
ZM2: ZM2_FILIAL C 2 0 | ZM2_COD C 6 0 (F3 ZM1) | ZM2_SEQ C 3 0 | ZM2_UNID C 2 0 Unidade/Filial (F3 SM0) | ZM2_DIAS C 7 0 Dias (Dow 1-7) | ZM2_HRINI C 5 0 Hora inicial (@R 99:99) | ZM2_HRFIN C 5 0 Hora final | ZM2_INTERV N 4 0 Intervalo min (0=única) | ZM2_ATIVO C 1 0 | ZM2_STATUS C 1 0 (visual, não editável) | ZM2_ULTSLT C 12 0 (não editável) | ZM2_ULTDT D 8 0 | ZM2_ULTHR C 8 0 | ZM2_TENT N 2 0
ZM3: ZM3_FILIAL C 2 0 | ZM3_ID C 10 0 (SXE/SXF GetSXENum) | ZM3_COD C 6 0 | ZM3_SEQ C 3 0 | ZM3_UNID C 2 0 | ZM3_SLOT C 12 0 | ZM3_TENT N 2 0 | ZM3_STATUS C 1 0 | ZM3_DATA D 8 0 | ZM3_HORA C 8 0 | ZM3_MSG C 250 0
Nota: HRINI/HRFIN com máscara 99:99 chegam como "HH:MM"; U_JMPMHM lê as 2 primeiras e posições 4-5.
