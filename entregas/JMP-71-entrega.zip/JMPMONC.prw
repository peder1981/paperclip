#include "totvs.ch"
#include "fwmvcdef.ch"

// Cadastro de funcoes (ZM1) com agenda por unidade/dia/hora (ZM2) e consulta do log (ZM3)
User Function JMPMONC()
	Local oBrw := FWMBrowse():New()
	oBrw:SetAlias("ZM1")
	oBrw:SetDescription("Monitor de Rotinas Agendadas")
	oBrw:Activate()
Return

Static Function MenuDef()
	Local aRot := {}
	ADD OPTION aRot TITLE "Visualizar" ACTION "VIEWDEF.JMPMONC" OPERATION MODEL_OPERATION_VIEW   ACCESS 0
	ADD OPTION aRot TITLE "Incluir"    ACTION "VIEWDEF.JMPMONC" OPERATION MODEL_OPERATION_INSERT ACCESS 0
	ADD OPTION aRot TITLE "Alterar"    ACTION "VIEWDEF.JMPMONC" OPERATION MODEL_OPERATION_UPDATE ACCESS 0
	ADD OPTION aRot TITLE "Excluir"    ACTION "VIEWDEF.JMPMONC" OPERATION MODEL_OPERATION_DELETE ACCESS 0
Return aRot

Static Function ModelDef()
	Local oSt1  := FWFormStruct(1, "ZM1")
	Local oSt2  := FWFormStruct(1, "ZM2")
	Local oMod  := MPFormModel():New("JMPMONCM", , {|oM| PosVld(oM)})
	oMod:AddFields("ZM1MASTER", , oSt1)
	oMod:AddGrid("ZM2DETAIL", "ZM1MASTER", oSt2)
	oMod:SetRelation("ZM2DETAIL", {{"ZM2_FILIAL", "xFilial('ZM2')"}, {"ZM2_COD", "ZM1_COD"}}, ZM2->(IndexKey(1)))
	oMod:GetModel("ZM2DETAIL"):SetUniqueLine({"ZM2_SEQ"})
	oMod:SetDescription("Monitor de Rotinas Agendadas")
Return oMod

Static Function ViewDef()
	Local oMod := FWLoadModel("JMPMONC")
	Local oView := FWFormView():New()
	oView:SetModel(oMod)
	oView:AddField("VIEW_ZM1", FWFormStruct(2, "ZM1"), "ZM1MASTER")
	oView:AddGrid("VIEW_ZM2", FWFormStruct(2, "ZM2"), "ZM2DETAIL")
	oView:CreateHorizontalBox("TOPO", 40)
	oView:CreateHorizontalBox("GRADE", 60)
	oView:SetOwnerView("VIEW_ZM1", "TOPO")
	oView:SetOwnerView("VIEW_ZM2", "GRADE")
Return oView

// A rotina cadastrada deve existir como User Function no RPO
Static Function PosVld(oM)
	Local cRot := Upper(AllTrim(oM:GetModel("ZM1MASTER"):GetValue("ZM1_ROTINA")))
	If oM:GetOperation() <> MODEL_OPERATION_DELETE .And. !ExistBlock(cRot)
		Help(, , "JMPMON", , "User Function " + cRot + " nao encontrada no RPO.", 1, 0)
		Return .F.
	EndIf
Return .T.
