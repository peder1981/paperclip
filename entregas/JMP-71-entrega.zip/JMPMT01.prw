#include "totvs.ch"

// Teste unitario da logica de agenda. RUN_RC = numero de falhas (0 = tudo OK). Segunda-feira 2026-10-26 (Dow=2).
User Function JMPMT01()
	Local nF := 0
	Local d := SToD("20261026")
	Local cS
	// unica 08:00, agora 08:05 -> dispara
	If U_JMPMSLOT("23456", "08:00", "", 0, 15, d, "08:05:00", "") <> "202610260800"; nF++; EndIf
	// unica 08:00, agora 07:59 -> nao
	If !Empty(U_JMPMSLOT("23456", "08:00", "", 0, 15, d, "07:59:59", "")); nF++; EndIf
	// fora da tolerancia (08:15) -> nao (perdido)
	If !Empty(U_JMPMSLOT("23456", "08:00", "", 0, 15, d, "08:15:00", "")); nF++; EndIf
	// ja executado (idempotencia)
	If !Empty(U_JMPMSLOT("23456", "08:00", "", 0, 15, d, "08:05:00", "202610260800")); nF++; EndIf
	// dia nao agendado (domingo)
	If !Empty(U_JMPMSLOT("23456", "08:00", "", 0, 15, SToD("20261025"), "08:05:00", "")); nF++; EndIf
	// intervalo 30 min 08:00-18:00, 10:40 -> slot 10:30
	If U_JMPMSLOT("2", "08:00", "18:00", 30, 15, d, "10:40:00", "") <> "202610261030"; nF++; EndIf
	// intervalo, antes da janela
	If !Empty(U_JMPMSLOT("2", "08:00", "18:00", 30, 15, d, "07:50:00", "")); nF++; EndIf
	// intervalo, mesmo slot ja executado, depois novo slot
	cS := U_JMPMSLOT("2", "08:00", "18:00", 30, 15, d, "10:40:00", "")
	If !Empty(U_JMPMSLOT("2", "08:00", "18:00", 30, 15, d, "10:41:00", cS)); nF++; EndIf
	If U_JMPMSLOT("2", "08:00", "18:00", 30, 15, d, "11:00:10", cS) <> "202610261100"; nF++; EndIf
	// fim da janela: 18:05 -> ultimo slot 18:00
	If U_JMPMSLOT("2", "08:00", "18:00", 30, 15, d, "18:05:00", "") <> "202610261800"; nF++; EndIf
	// depois da janela e da tolerancia
	If !Empty(U_JMPMSLOT("2", "08:00", "18:00", 30, 15, d, "18:30:00", "")); nF++; EndIf
	// diferenca em minutos cruzando dia
	If U_JMPMDIF(d, "23:50:00", d + 1, "00:10:00") <> 20; nF++; EndIf
Return nF
