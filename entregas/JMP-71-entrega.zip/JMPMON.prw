#include "totvs.ch"

// Monitor perpetuo (JMP-71). Job do AppServer ([ONSTART]) que le a agenda (ZM1/ZM2) e despacha cada execucao
// em thread propria (StartJob) por unidade (filial). Configuracao em [JMPMON] do appserver.ini: Empresa, Filial, Ciclo (seg), Standby (seg).
#define MON_LOCK  "JMPMON_SINGLETON"
#define MON_HB    "JMPMON_HB"

User Function JMPMONJ()
	Local cIni   := GetSrvIniName()
	Local cEmp   := GetPvProfString("JMPMON", "Empresa", "99", cIni)
	Local cFil   := GetPvProfString("JMPMON", "Filial", "01", cIni)
	Local nCiclo := Max(Val(GetPvProfString("JMPMON", "Ciclo", "30", cIni)), 5)
	Local nFalha := 0
	Local lSai   := .F.
	Local bOld
	Local cErro

	ConOut("[JMPMON] iniciado emp=" + cEmp + " fil=" + cFil + " ciclo=" + cValToChar(nCiclo) + "s")
	While !KillApp() .And. !lSai
		cErro := ""
		bOld  := ErrorBlock({|e| cErro := e:Description + " | " + e:ErrorStack, Break(e)})
		Begin Sequence
			RpcSetEnv(cEmp, cFil, , , "JMP", "JMPMON", {"ZM1", "ZM2", "ZM3"})
			If !LockByName(MON_LOCK, .T., .F.)
				// outra instancia ativa: fica em standby e assume se a ativa cair
				RpcClearEnv()
				Sleep(nCiclo * 1000)
				Break
			EndIf
			nFalha := 0
			While !KillApp()
				PutGlbValue(MON_HB, DToS(Date()) + " " + Time())
				JMPDespacha(GetEnvServer())
				Sleep(nCiclo * 1000)
			EndDo
			lSai := .T.
		End Sequence
		ErrorBlock(bOld)
		If !Empty(cErro)
			nFalha++
			ConOut("[JMPMON] falha no ciclo (" + cValToChar(nFalha) + "): " + cErro)
			UnLockByName(MON_LOCK, .T., .F.)
			RpcClearEnv()
			// backoff exponencial limitado a 10 min antes de reabrir o ambiente
			Sleep(Min(5 * (2 ^ Min(nFalha, 7)), 600) * 1000)
		EndIf
	EndDo
	UnLockByName(MON_LOCK, .T., .F.)
	ConOut("[JMPMON] encerrado")
Return

Static Function JMPDespacha(cEnv)
	Local dHoje := Date()
	Local cHora := Time()
	Local cSlot
	Local nRec
	Local cStat
	Local nToler

	DbSelectArea("ZM2")
	DbSetOrder(1)
	DbGoTop()
	While !ZM2->(Eof())
		If ZM2->ZM2_ATIVO == "S" .And. JMPFunc(ZM2->ZM2_COD)
			nToler := ZM1->ZM1_TOLER
			cStat  := ZM2->ZM2_STATUS
			cSlot  := ""
			If cStat == "R"
				// execucao em andamento: so verifica estouro de tempo
				If U_JMPMDIF(ZM2->ZM2_ULTDT, ZM2->ZM2_ULTHR, dHoje, cHora) > Max(ZM1->ZM1_TMOUT, 1)
					JMPMarca("T", ZM2->ZM2_ULTSLT, "Timeout: sem retorno do worker em " + cValToChar(ZM1->ZM1_TMOUT) + " min")
					cStat := "T"
				EndIf
			EndIf
			If cStat $ "ET" .And. ZM2->ZM2_TENT < ZM1->ZM1_RETRY .And. U_JMPMDIF(ZM2->ZM2_ULTDT, ZM2->ZM2_ULTHR, dHoje, cHora) >= ZM1->ZM1_BACKOF
				cSlot := ZM2->ZM2_ULTSLT // retentativa do mesmo slot
			ElseIf cStat <> "R"
				cSlot := U_JMPMSLOT(ZM2->ZM2_DIAS, ZM2->ZM2_HRINI, ZM2->ZM2_HRFIN, ZM2->ZM2_INTERV, nToler, dHoje, cHora, ZM2->ZM2_ULTSLT)
			EndIf
			If !Empty(cSlot)
				nRec := ZM2->(Recno())
				JMPDispara(cEnv, nRec, cSlot)
				ZM2->(DbGoTo(nRec))
			EndIf
		EndIf
		ZM2->(DbSkip())
	EndDo
Return

// Posiciona ZM1 pela chave da agenda e valida
Static Function JMPFunc(cCod)
	DbSelectArea("ZM1")
	DbSetOrder(1)
Return ZM1->(DbSeek(xFilial("ZM1") + cCod)) .And. ZM1->ZM1_ATIVO == "S"

Static Function JMPDispara(cEnv, nRec, cSlot)
	Local nTent := If(cSlot == ZM2->ZM2_ULTSLT, ZM2->ZM2_TENT + 1, 1)
	Local cEmp  := cEmpAnt
	Local cUnid := ZM2->ZM2_UNID

	RecLock("ZM2", .F.)
	ZM2->ZM2_STATUS := "R"
	ZM2->ZM2_ULTSLT := cSlot
	ZM2->ZM2_ULTDT  := Date()
	ZM2->ZM2_ULTHR  := Time()
	ZM2->ZM2_TENT   := nTent
	ZM2->(MsUnlock())
	If !StartJob("U_JMPMONX", cEnv, .F., cEmp, If(Empty(cUnid), cFilAnt, cUnid), nRec, cSlot, nTent)
		JMPMarca("E", cSlot, "StartJob recusou o despacho (limite de threads/ambiente)")
	EndIf
Return

Static Function JMPMarca(cStatus, cSlot, cMsg)
	RecLock("ZM2", .F.)
	ZM2->ZM2_STATUS := cStatus
	ZM2->ZM2_ULTDT  := Date()
	ZM2->ZM2_ULTHR  := Time()
	ZM2->(MsUnlock())
	JMPLog(ZM2->ZM2_COD, ZM2->ZM2_SEQ, ZM2->ZM2_UNID, cSlot, ZM2->ZM2_TENT, cStatus, cMsg)
Return

Static Function JMPLog(cCod, cSeq, cUnid, cSlot, nTent, cStatus, cMsg)
	RecLock("ZM3", .T.)
	ZM3->ZM3_FILIAL := xFilial("ZM3")
	ZM3->ZM3_ID     := GetSXENum("ZM3", "ZM3_ID")
	ZM3->ZM3_COD    := cCod
	ZM3->ZM3_SEQ    := cSeq
	ZM3->ZM3_UNID   := cUnid
	ZM3->ZM3_SLOT   := cSlot
	ZM3->ZM3_TENT   := nTent
	ZM3->ZM3_STATUS := cStatus
	ZM3->ZM3_DATA   := Date()
	ZM3->ZM3_HORA   := Time()
	ZM3->ZM3_MSG    := Left(cMsg, 250)
	ZM3->(MsUnlock())
	ConfirmSX8()
Return

// Worker: thread propria por execucao. Params: empresa, unidade(filial), recno da ZM2, slot, tentativa.
User Function JMPMONX(cEmp, cUnid, nRec, cSlot, nTent)
	Local cStat := "O"
	Local cMsg  := "OK"
	Local cCod, cSeq, cRotina
	Local bOld
	Local xRet

	RpcSetEnv(cEmp, cUnid, , , "JMP", "JMPMONX", {"ZM1", "ZM2", "ZM3"})
	DbSelectArea("ZM2")
	ZM2->(DbGoTo(nRec))
	cCod := ZM2->ZM2_COD
	cSeq := ZM2->ZM2_SEQ
	DbSelectArea("ZM1")
	DbSetOrder(1)
	ZM1->(DbSeek(xFilial("ZM1") + cCod))
	cRotina := Upper(AllTrim(ZM1->ZM1_ROTINA))
	bOld := ErrorBlock({|e| cMsg := "ERRO: " + e:Description + " | " + e:ErrorStack, cStat := "E", Break(e)})
	Begin Sequence
		// so User Functions cadastradas: nunca macro-execucao de texto livre
		If Empty(cRotina) .Or. !ExistBlock(cRotina)
			cStat := "E"
			cMsg  := "Rotina " + cRotina + " nao existe no RPO como User Function"
		Else
			xRet := ExecBlock(cRotina, .F., .F., {cEmp, cUnid, cSlot})
			If ValType(xRet) == "L" .And. !xRet
				cStat := "E"
				cMsg  := "Rotina retornou .F."
			EndIf
		EndIf
	End Sequence
	ErrorBlock(bOld)

	ZM2->(DbGoTo(nRec))
	RecLock("ZM2", .F.)
	ZM2->ZM2_STATUS := cStat
	ZM2->ZM2_ULTDT  := Date()
	ZM2->ZM2_ULTHR  := Time()
	If cStat == "O"
		ZM2->ZM2_TENT := 0
	EndIf
	ZM2->(MsUnlock())
	JMPLog(cCod, cSeq, cUnid, cSlot, nTent, cStat, cMsg)
	RpcClearEnv()
Return

// Consulta de saude: heartbeat do laco (para monitoramento externo / REST)
User Function JMPMONS()
Return GetGlbValue(MON_HB)
