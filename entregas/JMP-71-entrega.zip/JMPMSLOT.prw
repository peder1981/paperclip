#include "totvs.ch"

// Logica pura de agenda (sem acesso a banco): devolve a chave do slot devido ou "" se nao ha execucao a fazer.
// cDias: digitos Dow() ("1"=dom..."7"=sab). nInt=0 -> execucao unica em cHrIni; nInt>0 -> a cada nInt min entre cHrIni e cHrFin.
// nToler: minutos apos o slot em que ainda e permitido executar (catch-up). cUltSlt: ultimo slot ja disparado (idempotencia).
User Function JMPMSLOT(cDias, cHrIni, cHrFin, nInt, nToler, dRef, cHrRef, cUltSlt)
	Local nAgora := U_JMPMHM(cHrRef)
	Local nIni   := U_JMPMHM(cHrIni)
	Local nFin   := U_JMPMHM(cHrFin)
	Local nSlot  := 0
	Local cSlot  := ""

	If !(cValToChar(Dow(dRef)) $ AllTrim(cDias))
		Return ""
	EndIf
	If nToler <= 0
		nToler := 15
	EndIf
	If nInt <= 0
		nSlot := nIni
	Else
		If nFin < nIni
			nFin := 1439
		EndIf
		If nAgora < nIni
			Return ""
		EndIf
		nSlot := nIni + Int((Min(nAgora, nFin) - nIni) / nInt) * nInt
	EndIf
	If nAgora < nSlot .Or. (nAgora - nSlot) >= nToler
		Return ""
	EndIf
	cSlot := DToS(dRef) + StrZero(Int(nSlot / 60), 2) + StrZero(Mod(nSlot, 60), 2)
	If cSlot == AllTrim(cUltSlt)
		Return ""
	EndIf
Return cSlot

// "HH:MM[:SS]" -> minutos desde 00:00
User Function JMPMHM(cHora)
	cHora := AllTrim(cHora)
Return Val(SubStr(cHora, 1, 2)) * 60 + Val(SubStr(cHora, 4, 2))

// Diferenca em minutos entre dois instantes (data + HH:MM:SS)
User Function JMPMDIF(dD1, cH1, dD2, cH2)
Return (dD2 - dD1) * 1440 + U_JMPMHM(cH2) - U_JMPMHM(cH1)
