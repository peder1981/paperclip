# JMP-71 — Monitor perpétuo Protheus (agenda por tabela: unidade/dia/hora)

Ambiente: teste 12.1.2510 (empresa 99). Autor: Dev Protheus Sênior. Data: 29/10/2026.

## 1. Mecanismo escolhido
**Job de AppServer via [ONSTART]** (laço perpétuo) + **workers em StartJob**. Descartados:
- Schedule do Protheus (SCHEDULE/APPSERVER): granularidade mínima e agenda no cadastro do próprio schedule (não por tabela de unidade/dia/hora com tolerância/retentativa/log próprio).
- Job só com Sleep sem workers: uma rotina travada pararia todas as outras.

Fluxo: o AppServer sobe -> `[ONSTART]` inicia `U_JMPMONJ` -> a cada ciclo (padrão 30 s) lê ZM2 (agenda), calcula o slot devido (`U_JMPMSLOT`) e despacha cada execução em thread própria `U_JMPMONX` (StartJob, ambiente da unidade/filial). O worker executa a User Function cadastrada via `ExecBlock` (nunca macro de texto livre), grava status em ZM2 e log em ZM3.

appserver.ini:
```
[ONSTART]
Jobs=JMPMON
RefreshRate=60
[JMPMON]
Main=U_JMPMONJ
Environment=P2510
Empresa=99
Filial=01
Ciclo=30
```
(`Empresa`/`Filial`/`Ciclo` lidos por GetPvProfString; para outra empresa, outra seção/instância. Tabelas ZM* são por empresa.)

## 2. Tabelas custom (dicionário SX2/SX3/SIX — script em `dicionario-ZM.md`)
- **ZM1 Cadastro de funções** (compartilhada): COD, DESC, ROTINA (User Function sem "U_"), ATIVO, TOLER (min, padrão 15), TMOUT (min), RETRY (nº retentativas), BACKOF (min entre tentativas).
- **ZM2 Agenda** (compartilhada, filha de ZM1): COD, SEQ, UNID (filial de execução), DIAS (dígitos Dow: 1=dom..7=sáb, ex. "23456"), HRINI, HRFIN, INTERV (min; 0 = execução única em HRINI), ATIVO + controle: ULTSLT (último slot disparado), ULTDT/ULTHR, STATUS (R=rodando O=ok E=erro T=timeout), TENT.
- **ZM3 Log de execução**: ID, COD, SEQ, UNID, SLOT, TENT, STATUS, DATA, HORA, MSG.
Cadastro: MVC `U_JMPMONC` (ZM1 mestre + grade ZM2); valida que a User Function existe no RPO.

## 3. Regras de agenda (testadas)
- Slot = `AAAAMMDDHHMM`. Dispara se hoje ∈ DIAS, agora ≥ slot e (agora − slot) < TOLER. Idempotência por ULTSLT: o mesmo slot nunca roda duas vezes.
- Intervalo: slots de HRINI a HRFIN a cada INTERV min; executa o slot mais recente dentro da tolerância (sem rajada de atrasados).
- Slot perdido além da tolerância é pulado (não executa retroativo).
- Janela não cruza meia-noite (v1): usar duas linhas de agenda.

## 4. Tratamento de falha
- Erro/`.F.` da rotina: STATUS=E, log com `e:Description + ErrorStack`; retentativa do **mesmo slot** até RETRY, esperando BACKOF min.
- Worker sem retorno > TMOUT min: master marca T (timeout) e aplica a mesma retentativa. Não mata a thread (limitação: ver §6).
- StartJob recusado: E + log.
- Queda do laço (erro de ambiente/banco): captura via ErrorBlock, RpcClearEnv, reabre com backoff exponencial (5 s … 10 min).
- Instância única: `LockByName("JMPMON_SINGLETON")`; segunda instância fica em standby e assume se a ativa cair.
- Reinício do AppServer: ONSTART reinicia o laço; slots já disparados não repetem (ULTSLT em tabela, não em memória).
- Saúde: `GetGlbValue("JMPMON_HB")` (`U_JMPMONS`) = heartbeat a cada ciclo; monitoramento externo alerta se > 2 ciclos.

## 5. Evidências (teste, canal compile/run)
- JMPMSLOT.prw, JMPMT01.prw, JMPMON.prw, JMPMONC.prw: COMPILE_RC=0, Success(1) Errors(0) cada (compile_*.log).
- `run U_JMPMT01` (12 asserts: única/intervalo/tolerância/idempotência/dia não agendado/fim de janela/virada de dia): RUN_RC=0 = 0 falhas (run_JMPMT01.log).

## 6. NÃO VERIFICADO / pendências
- Dicionário ZM1/ZM2/ZM3 **não aplicado**: o container de compilação não tem banco/SX e RpcSetEnv no AppServer vivo trava pelo canal `run` (limite 120 s; mesmo achado do JMP-60). Aplicar no teste via UPDDISTR/configurador a partir de `dicionario-ZM.md`.
- Laço, worker e MVC compilam mas **não foram executados** contra banco (dependem das tabelas). Sem teste de StartJob, ExecBlock, LockByName e RecLock reais.
- Timeout não encerra a thread do worker (só sinaliza); matar thread exige KillUser/monitor — fora da v1.
- Purga de ZM3 e alerta por e-mail em falhas repetidas: não incluídos (sugestão v2).
- "Ambiente 990" interpretado como empresa 99 / filial 0x do dicionário de teste; confirmar se há ambiente distinto.
